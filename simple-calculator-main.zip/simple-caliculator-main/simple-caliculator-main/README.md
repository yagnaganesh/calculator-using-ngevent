# simple-caliculator

Caliculator using onclick event and evaluation method
